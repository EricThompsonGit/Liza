
public enum Task {
	Mine,
	Claim,
	AttackMiner,
	AttackShip,
	AttackPlanet
}
