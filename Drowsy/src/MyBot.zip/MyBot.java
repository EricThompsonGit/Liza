
import Drowsy.Bot;


public class MyBot {

    public static void main(final String[] args) {
    	Bot bot = new Bot( "MyBot");
    	bot.run();
	}

}
