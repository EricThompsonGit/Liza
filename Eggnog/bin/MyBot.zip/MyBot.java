
import eggnog.Bot;


public class MyBot {

    public static void main(final String[] args) {
    	Bot bot = new Bot( "eggnog");
    	bot.run();
	}

}
